-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 29 avr. 2022 à 01:29
-- Version du serveur : 10.4.22-MariaDB
-- Version de PHP : 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `adelo`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `idc` int(4) NOT NULL,
  `nom` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `adresse_exp` varchar(200) NOT NULL,
  `adresse_fac` varchar(200) NOT NULL,
  `personne_contact` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id_comm` int(4) NOT NULL,
  `dateCreation` date NOT NULL,
  `idc` int(4) NOT NULL,
  `quantite` int(4) NOT NULL,
  `prix` decimal(7,2) NOT NULL,
  `reference` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `devi`
--

CREATE TABLE `Devi` (
  `idD` int(4) NOT NULL,
  `date_emisD` date NOT NULL,
  `qteD` decimal(7,2) NOT NULL,
  `remiseD` decimal(7,2) NOT NULL,
  `serieD` varchar(50) NOT NULL,
  `taxeD` decimal(7,2) NOT NULL,
  `referenceD` varchar(50) NOT NULL,
  `idcD` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `Facture` (
  `idf` int(4) NOT NULL,
  `referencF` varchar(50) DEFAULT NULL,
  `idcF` int(4) DEFAULT NULL,
  `date_ech` date DEFAULT NULL,
  `date_emis` date DEFAULT NULL,
  `serie` varchar(50) DEFAULT NULL,
  `remise` decimal(7,2) DEFAULT NULL,
  `taxe` decimal(7,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `paied` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `reference` varchar(50) NOT NULL,
  `cout_unitaire` int(4) NOT NULL,
  `description` varchar(200) NOT NULL,
  `dateCreation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `numtel` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `dateCreation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`idc`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_comm`),
  ADD KEY `idc` (`idc`),
  ADD KEY `reference` (`reference`);

--
-- Index pour la table `devi`
--
ALTER TABLE `Devi`
  ADD PRIMARY KEY (`idD`),
  ADD KEY `referenceD` (`referenceD`);

--
-- Index pour la table `facture`
--
ALTER TABLE `Facture`
  ADD PRIMARY KEY (`idf`),
  ADD KEY `idcF` (`idcF`),
  ADD KEY `referencF` (`referencF`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`reference`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`username`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`idc`) REFERENCES `client` (`idc`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`reference`) REFERENCES `produit` (`reference`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `devi`
--
ALTER TABLE `Devi`
  ADD CONSTRAINT `Devi_ibfk_1` FOREIGN KEY (`referenceD`) REFERENCES `produit` (`reference`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `facture`
--
ALTER TABLE `Facture`
  ADD CONSTRAINT `Facture_ibfk_1` FOREIGN KEY (`idcF`) REFERENCES `client` (`idc`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Facture_ibfk_2` FOREIGN KEY (`referencF`) REFERENCES `produit` (`reference`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;